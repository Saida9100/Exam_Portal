import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import AppLayout from "./components/AppLayout";
import RequireAuth from "./auth/RequireAuth";

import LoginPage from "./components/pages/LoginPage";
import Dashboard from "./components/pages/Dashboard";
import Exams from "./components/pages/Exams";
import CreateExam from "./components/pages/CreateExam";
import ExamTaking from "./components/pages/ExamTaking";
import Proctoring from "./components/pages/Proctoring";
import Results from "./components/pages/Results";
import Students from "./components/pages/Students";
import Admins from "./components/pages/Admins";
import Documents from "./components/pages/Documents";
import Settings from "./components/pages/Settings";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="/login" element={<LoginPage />} />

      {/* All app routes require login */}
      <Route
        path="/app"
        element={
          <RequireAuth>
            <AppLayout />
          </RequireAuth>
        }
      >
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="exams" element={<Exams />} />
        <Route path="taking" element={<ExamTaking />} />
        <Route path="results" element={<Results />} />

        {/* Admin + Super Admin only */}
        <Route
          path="create"
          element={
            <RequireAuth roles={["admin", "superadmin"]}>
              <CreateExam />
            </RequireAuth>
          }
        />
        <Route
          path="proctor"
          element={
            <RequireAuth roles={["admin", "superadmin"]}>
              <Proctoring />
            </RequireAuth>
          }
        />
        <Route
          path="students"
          element={
            <RequireAuth roles={["admin", "superadmin"]}>
              <Students />
            </RequireAuth>
          }
        />
        <Route
          path="documents"
          element={
            <RequireAuth roles={["admin", "superadmin"]}>
              <Documents />
            </RequireAuth>
          }
        />

        {/* Super Admin only */}
        <Route
          path="admins"
          element={
            <RequireAuth roles={["superadmin"]}>
              <Admins />
            </RequireAuth>
          }
        />
        <Route
          path="settings"
          element={
            <RequireAuth roles={["superadmin"]}>
              <Settings />
            </RequireAuth>
          }
        />
      </Route>

      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}
