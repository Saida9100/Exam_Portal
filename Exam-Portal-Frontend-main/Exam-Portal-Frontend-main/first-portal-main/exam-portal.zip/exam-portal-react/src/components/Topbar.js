import React from "react";
import Icon from "./ui/Icon";
import Avatar from "./ui/Avatar";
import Badge from "./ui/Badge";
import { useAuth } from "../auth/AuthContext";

function roleBadge(role) {
  if (role === "superadmin") return <Badge tone="danger">Super Admin</Badge>;
  if (role === "admin") return <Badge>Admin</Badge>;
  return <Badge tone="success">Student</Badge>;
}

export default function Topbar({ title, crumbs }) {
  const { user } = useAuth();

  return (
    <header className="topbar">
      <div>
        <h1>{title}</h1>
        <div className="crumbs">{crumbs}</div>
      </div>
      <div className="top-actions">
        <div className="search">
          <Icon name="search" size={16} />
          <input placeholder="Search exams, students, results…" />
        </div>
        <button className="icon-btn" title="Notifications">
          <Icon name="bell" size={18} />
          <span className="dotnotif" />
        </button>
        <button className="icon-btn" title="Help">
          <Icon name="help" size={18} />
        </button>
        {user && roleBadge(user.role)}
        <Avatar initials={user?.initials || "U"} gradient={user?.gradient || "#6366f1,#22d3ee"} />
      </div>
    </header>
  );
}
