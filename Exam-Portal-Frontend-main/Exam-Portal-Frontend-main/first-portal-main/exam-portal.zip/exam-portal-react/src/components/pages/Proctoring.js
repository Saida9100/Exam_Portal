import React from "react";
import { Card, CardHead } from "../ui/Card";
import StatCard from "../ui/StatCard";
import Badge from "../ui/Badge";
import Avatar from "../ui/Avatar";
import EmptyState from "../ui/EmptyState";
import { PROCTOR_FLAGS } from "../../data/mock";

export default function Proctoring() {
  return (
    <>
      <div className="grid grid-3 mb-18">
        <StatCard label="Active sessions" value="0" delta="No exams running" icon="camera" />
        <StatCard label="Flagged students" value="0" delta="All clear" icon="alert" tone="orange" />
        <StatCard label="Violations today" value="0" delta="No violations" icon="ban" tone="red" />
      </div>

      <Card>
        <CardHead
          title="Detected suspicious activity"
          subtitle="Students flagged by AI proctor in the last hour"
          right={<button className="btn btn-outline">⬇️ Export report</button>}
        />
        {PROCTOR_FLAGS.length > 0 ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Student</th>
                  <th>Exam</th>
                  <th>Violation</th>
                  <th>Count</th>
                  <th>Last detected</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {PROCTOR_FLAGS.map((p) => (
                  <tr key={p.id} className="row-hover">
                    <td>
                      <div className="user-cell">
                        <Avatar initials={p.initials} gradient={p.grad} size="sm" />
                        <div>
                          <div className="cell-strong">{p.name}</div>
                          <div style={{ fontSize: 11.5, color: "var(--muted)" }}>{p.roll}</div>
                        </div>
                      </div>
                    </td>
                    <td>{p.exam}</td>
                    <td>{p.violation}</td>
                    <td>{p.count}</td>
                    <td>{p.time}</td>
                    <td><Badge tone={p.tone}>{p.risk} risk</Badge></td>
                    <td><button className="ghost-link">Review</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon="🛡️"
            title="No suspicious activity detected"
            message="When AI proctoring flags a candidate, they'll appear here in real time."
          />
        )}
      </Card>
    </>
  );
}
