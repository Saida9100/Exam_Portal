import React, { useState } from "react";
import { Card } from "../ui/Card";
import Avatar from "../ui/Avatar";
import EmptyState from "../ui/EmptyState";
import Modal from "../ui/Modal";
import { useData } from "../../data/DataContext";

export default function Students() {
  const { students, addStudent, removeStudent } = useData();
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    name: "",
    email: "",
    roll: "",
    branch: "",
    password: "",
  });

  const update = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = (e) => {
    e.preventDefault();
    setError("");
    const res = addStudent(form);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    setForm({ name: "", email: "", roll: "", branch: "", password: "" });
    setOpen(false);
  };

  return (
    <>
      <div className="toolbar">
        <div style={{ fontSize: 13, color: "var(--muted)" }}>
          Showing {students.length} student{students.length === 1 ? "" : "s"}
        </div>
        <div className="right">
          <button className="btn btn-outline">⬆️ Bulk import CSV</button>
          <button className="btn btn-primary" onClick={() => setOpen(true)}>
            + Add Student
          </button>
        </div>
      </div>

      <Card>
        {students.length > 0 ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Student</th>
                  <th>Roll No.</th>
                  <th>Email</th>
                  <th>Branch</th>
                  <th>Exams taken</th>
                  <th>Avg. score</th>
                  <th>Added</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {students.map((s) => (
                  <tr key={s.id} className="row-hover">
                    <td>
                      <div className="user-cell">
                        <Avatar initials={s.initials} gradient={s.gradient} size="sm" />
                        <span className="cell-strong">{s.name}</span>
                      </div>
                    </td>
                    <td>{s.roll}</td>
                    <td>{s.email}</td>
                    <td>{s.branch}</td>
                    <td>{s.taken}</td>
                    <td className="cell-strong">{s.avg}</td>
                    <td>{s.createdAt}</td>
                    <td>
                      <button
                        className="ghost-link"
                        style={{ color: "var(--danger)" }}
                        onClick={() => removeStudent(s.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon="👥"
            title="No students added yet"
            message="Add students one-by-one or import a CSV to populate your portal."
            action={
              <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
                <button className="btn btn-outline">⬆️ Bulk import CSV</button>
                <button className="btn btn-primary" onClick={() => setOpen(true)}>
                  + Add Student
                </button>
              </div>
            }
          />
        )}
      </Card>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Add a new student"
        subtitle="Create a student account. They can sign in with the email & password you set."
      >
        <form onSubmit={submit}>
          {error && (
            <div
              className="alert"
              style={{
                background: "var(--danger-soft)",
                color: "#991b1b",
                borderColor: "#fecaca",
                marginBottom: 14,
              }}
            >
              <div>⚠️</div>
              <div>{error}</div>
            </div>
          )}

          <div className="form-row">
            <div className="field">
              <label>Full name *</label>
              <input
                placeholder="e.g. Sai Ram"
                value={form.name}
                onChange={(e) => update("name", e.target.value)}
                required
              />
            </div>
            <div className="field">
              <label>Roll number *</label>
              <input
                placeholder="e.g. 21CS001"
                value={form.roll}
                onChange={(e) => update("roll", e.target.value)}
                required
              />
            </div>
          </div>
          <div className="field">
            <label>Email *</label>
            <input
              type="email"
              placeholder="student@yourinstitution.edu"
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              required
            />
          </div>
          <div className="form-row">
            <div className="field">
              <label>Branch / Department</label>
              <input
                placeholder="e.g. CSE"
                value={form.branch}
                onChange={(e) => update("branch", e.target.value)}
              />
            </div>
            <div className="field">
              <label>Temporary password</label>
              <input
                type="text"
                placeholder="Min. 6 characters"
                value={form.password}
                onChange={(e) => update("password", e.target.value)}
              />
            </div>
          </div>
          <div className="field-help" style={{ marginBottom: 14 }}>
            Tip: Share the email + password with the student. They can change the
            password from their profile after first login.
          </div>

          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
            <button type="button" className="btn btn-outline" onClick={() => setOpen(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              ✓ Create student
            </button>
          </div>
        </form>
      </Modal>
    </>
  );
}
