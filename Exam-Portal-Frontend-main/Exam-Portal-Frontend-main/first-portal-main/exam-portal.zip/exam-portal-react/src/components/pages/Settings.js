import React from "react";
import { Card, CardHead } from "../ui/Card";

export default function Settings() {
  return (
    <Card>
      <CardHead
        title="Portal settings"
        subtitle="Super-admin only — configure global behaviour of the platform"
      />
      <div className="card-pad">
        <div className="form-row">
          <div className="field">
            <label>Institution name</label>
            <input placeholder="e.g. ExamPortal Institute of Technology" />
          </div>
          <div className="field">
            <label>Support email</label>
            <input placeholder="support@yourinstitution.edu" />
          </div>
        </div>
        <div className="form-row">
          <div className="field">
            <label>Default exam duration (min)</label>
            <input type="number" placeholder="60" />
          </div>
          <div className="field">
            <label>Passing threshold (%)</label>
            <input type="number" placeholder="40" />
          </div>
        </div>

        <h4 style={{ margin: "18px 0 10px", fontSize: 14 }}>Proctoring</h4>
        <div style={{ display: "grid", gap: 10 }}>
          <label className="check"><input type="checkbox" defaultChecked /> Require webcam access for all exams</label>
          <label className="check"><input type="checkbox" defaultChecked /> Detect multiple faces in frame</label>
          <label className="check"><input type="checkbox" defaultChecked /> Detect tab/window switching</label>
          <label className="check"><input type="checkbox" /> Disable copy/paste during exam</label>
        </div>

        <div style={{ marginTop: 18, textAlign: "right" }}>
          <button className="btn btn-primary">Save changes</button>
        </div>
      </div>
    </Card>
  );
}
