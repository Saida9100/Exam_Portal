import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Icon from "../ui/Icon";
import { useAuth } from "../../auth/AuthContext";
import { DEMO_CREDENTIALS } from "../../data/auth";

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState("");

  const fillDemo = (role) => {
    const d = DEMO_CREDENTIALS.find((c) => c.role === role);
    if (d) {
      setEmail(d.email);
      setPassword(d.password);
      setError("");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");
    const result = login(email, password);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    const dest = location.state?.from?.pathname || "/app/dashboard";
    navigate(dest, { replace: true });
  };

  return (
    <div className="login-wrap">
      {/* Hero panel */}
      <div className="login-hero">
        <div className="lh-brand">
          <div className="sb-logo">EP</div>
          <div>
            <div style={{ fontSize: 16, fontWeight: 700 }}>ExamPortal</div>
            <div style={{ fontSize: 12, opacity: 0.85 }}>
              Secure Online Examinations
            </div>
          </div>
        </div>

        <div>
          <h1 className="lh-title">
            Conduct fair, secure &amp; intelligent online examinations.
          </h1>
          <p className="lh-sub">
            An end-to-end platform for institutions to create exams, monitor
            candidates with AI proctoring, and instantly analyse results.
          </p>

          <div className="lh-features">
            <div className="lh-feature">
              <span className="chk">✓</span> AI-powered live proctoring &amp; face detection
            </div>
            <div className="lh-feature">
              <span className="chk">✓</span> Auto-graded MCQs, descriptive &amp; coding sections
            </div>
            <div className="lh-feature">
              <span className="chk">✓</span> Instant analytics &amp; one-click PDF / Excel export
            </div>
            <div className="lh-feature">
              <span className="chk">✓</span> Role-based access for Super Admins, Admins &amp; Students
            </div>
          </div>
        </div>

        <div className="lh-footer">© 2026 ExamPortal • Trusted by 200+ institutions</div>
      </div>

      {/* Form panel */}
      <div className="login-form-wrap">
        <form className="login-card" onSubmit={handleSubmit}>
          <h2>Welcome back 👋</h2>
          <p className="lead">Sign in to access your dashboard, exams and reports.</p>

          {error && (
            <div
              className="alert"
              style={{
                background: "var(--danger-soft)",
                color: "#991b1b",
                borderColor: "#fecaca",
                marginBottom: 14,
              }}
            >
              <div>⚠️</div>
              <div>{error}</div>
            </div>
          )}

          <div className="field">
            <label>Email address</label>
            <input
              type="email"
              placeholder="name@yourinstitution.edu"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <div className="field-help">
              Use the email provided by your administrator.
            </div>
          </div>

          <div className="field">
            <label>Password</label>
            <div className="pw-wrap">
              <input
                type={showPw ? "text" : "password"}
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <button
                type="button"
                className="pw-toggle"
                onClick={() => setShowPw((v) => !v)}
                title="Show / hide password"
              >
                <Icon name="eye" size={18} />
              </button>
            </div>
          </div>

          <div className="row-between">
            <label className="check">
              <input
                type="checkbox"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
              />
              Remember me
            </label>
            <a href="#forgot">Forgot password?</a>
          </div>

          <button className="btn btn-primary btn-block" type="submit" style={{ padding: 12 }}>
            Sign in <Icon name="arrow" size={16} />
          </button>

          <div className="divider">Demo credentials</div>

          {/* Demo logins for quick testing */}
          <div style={{ display: "grid", gap: 8 }}>
            {DEMO_CREDENTIALS.map((c) => (
              <button
                key={c.role}
                type="button"
                onClick={() => fillDemo(c.role)}
                className="btn btn-outline"
                style={{ justifyContent: "space-between", textAlign: "left" }}
              >
                <span style={{ display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
                  <strong style={{ fontSize: 13 }}>{c.label}</strong>
                  <span style={{ fontSize: 11, color: "var(--muted)", fontWeight: 500 }}>
                    {c.email} · {c.password}
                  </span>
                </span>
                <span className="badge muted">Use</span>
              </button>
            ))}
          </div>

          <p style={{ textAlign: "center", color: "var(--muted)", fontSize: 12, marginTop: 18 }}>
            Don't have credentials? <a href="#contact">Contact your administrator</a>
          </p>
        </form>
      </div>
    </div>
  );
}
