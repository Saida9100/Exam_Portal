import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardHead } from "../ui/Card";
import Badge from "../ui/Badge";
import Icon from "../ui/Icon";
import EmptyState from "../ui/EmptyState";
import { QUESTIONS, PALETTE } from "../../data/mock";

function useCountdown(initialSeconds) {
  const [s, setS] = useState(initialSeconds);
  useEffect(() => {
    const id = setInterval(() => setS((v) => Math.max(0, v - 1)), 1000);
    return () => clearInterval(id);
  }, []);
  const m = String(Math.floor(s / 60)).padStart(2, "0");
  const sec = String(s % 60).padStart(2, "0");
  return `${m}:${sec}`;
}

export default function ExamTaking() {
  const navigate = useNavigate();
  const time = useCountdown(60 * 60);
  const q = QUESTIONS[0];
  const [selected, setSelected] = useState(null);

  if (!q) {
    return (
      <Card>
        <EmptyState
          icon="🕐"
          title="No active exam"
          message="You don't have any exam in progress. Go to Exams to see what's available."
          action={
            <button className="btn btn-primary" onClick={() => navigate("/app/exams")}>
              View available exams
            </button>
          }
        />
      </Card>
    );
  }

  return (
    <div className="exam-wrap">
      <div>
        <Card>
          <CardHead
            title="Live Exam"
            subtitle="Answer each question carefully — autosave on every change"
            right={
              <div className="qtimer">
                <Icon name="clock" size={18} />
                <span>{time}</span> remaining
              </div>
            }
          />
          <div className="card-pad">
            <div className="qmeta">
              <Badge>Question 1 of {QUESTIONS.length}</Badge>
              <Badge tone="success">Answered: 0</Badge>
              <Badge tone="warn">Flagged: 0</Badge>
              <Badge tone="muted">Unanswered: {QUESTIONS.length}</Badge>
            </div>
            <div className="progress">
              <div className="progress-bar" style={{ width: "0%" }} />
            </div>

            <div className="question">{q.text}</div>

            <div className="options">
              {q.options.map((o, idx) => (
                <label
                  key={idx}
                  className={`opt ${selected === idx ? "selected" : ""}`}
                  onClick={() => setSelected(idx)}
                >
                  <span className="opt-letter">{String.fromCharCode(65 + idx)}</span>
                  <input type="radio" name="q" checked={selected === idx} onChange={() => setSelected(idx)} />
                  <span className="opt-text">{o}</span>
                </label>
              ))}
            </div>

            <div className="qnav">
              <button className="btn btn-outline">← Previous</button>
              <div style={{ display: "flex", gap: 8 }}>
                <button className="btn btn-ghost">🚩 Flag for review</button>
                <button className="btn btn-outline">Save &amp; Mark for Review</button>
                <button className="btn btn-primary">Save &amp; Next →</button>
              </div>
            </div>
          </div>
        </Card>
      </div>

      <div>
        <Card className="mb-18">
          <CardHead title="🎥 Live Proctoring" subtitle="AI monitoring enabled" />
          <div className="card-pad">
            <div className="proctor-cam">
              <div className="rec"><span className="dot" /> REC</div>
              <div className="face-box" />
              <div style={{ fontSize: 12 }}>Camera feed</div>
            </div>
            <div className="proctor-status">
              <div className="status-row"><span>Face detected</span><Badge tone="success">✓ OK</Badge></div>
              <div className="status-row"><span>Multiple faces</span><Badge tone="success">✓ None</Badge></div>
              <div className="status-row"><span>Looking away</span><Badge tone="muted">0</Badge></div>
              <div className="status-row"><span>Tab switches</span><Badge tone="muted">0</Badge></div>
            </div>
          </div>
        </Card>

        <Card>
          <CardHead title="Question palette" subtitle="Click any number to jump" />
          <div className="card-pad">
            {PALETTE.length > 0 ? (
              <div className="qpalette">
                {PALETTE.map((p) => (
                  <div key={p.n} className={`qbox ${p.state}`}>{p.n}</div>
                ))}
              </div>
            ) : (
              <div style={{ textAlign: "center", color: "var(--muted)", fontSize: 12, padding: 20 }}>
                The palette will populate as the exam loads.
              </div>
            )}
            <div className="legend">
              <span><span className="sq" style={{ background: "var(--brand)" }} /> Current</span>
              <span><span className="sq" style={{ background: "var(--success-soft)" }} /> Answered</span>
              <span><span className="sq" style={{ background: "var(--warning-soft)" }} /> Flagged</span>
              <span><span className="sq" /> Unanswered</span>
            </div>
            <button className="btn btn-danger btn-block" style={{ marginTop: 16 }}>
              ⏏ Submit Exam
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}
