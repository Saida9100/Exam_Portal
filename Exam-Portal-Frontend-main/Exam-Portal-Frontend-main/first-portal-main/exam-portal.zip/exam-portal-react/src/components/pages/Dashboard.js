import React from "react";
import { Card, CardHead } from "../ui/Card";
import StatCard from "../ui/StatCard";
import Badge from "../ui/Badge";
import Avatar from "../ui/Avatar";
import EmptyState from "../ui/EmptyState";
import { useAuth } from "../../auth/AuthContext";
import { KPIS, WEEK_PERF, UPCOMING, RECENT_ACTIVITY } from "../../data/mock";

export default function Dashboard() {
  const { user } = useAuth();

  return (
    <>
      <Card className="mb-18">
        <div className="card-pad" style={{ display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
          <Avatar initials={user?.initials || "U"} gradient={user?.gradient || "#6366f1,#22d3ee"} />
          <div style={{ flex: 1, minWidth: 240 }}>
            <div style={{ fontSize: 18, fontWeight: 700 }}>
              Welcome, {user?.name || "Guest"} 👋
            </div>
            <div style={{ color: "var(--muted)", fontSize: 13 }}>
              You're signed in as <strong style={{ color: "var(--ink-2)" }}>{user?.role}</strong>. Your dashboard will populate as data is added.
            </div>
          </div>
          <button className="btn btn-primary">+ Get started</button>
        </div>
      </Card>

      {KPIS.length > 0 ? (
        <div className="grid grid-4 mb-18">
          {KPIS.map((k) => (
            <StatCard key={k.label} {...k} />
          ))}
        </div>
      ) : (
        <div className="grid grid-4 mb-18">
          {["Total Exams", "Active Students", "Ongoing Live", "Avg. Pass Rate"].map((label, i) => (
            <StatCard
              key={label}
              label={label}
              value="—"
              delta="No data yet"
              icon={["exam", "users", "clock", "chart"][i]}
              tone={["", "green", "orange", "blue"][i]}
            />
          ))}
        </div>
      )}

      <div className="grid" style={{ gridTemplateColumns: "2fr 1fr" }}>
        <Card>
          <CardHead
            title="Exam performance — last 7 days"
            subtitle="Average score across all completed exams"
            right={
              <div className="pill-tabs">
                <button className="active">7d</button>
                <button>30d</button>
                <button>90d</button>
              </div>
            }
          />
          <div className="card-pad">
            {WEEK_PERF.length > 0 ? (
              <div className="barchart">
                {WEEK_PERF.map((d) => (
                  <div className="bc-col" key={d.day}>
                    <div className="bc-bar" style={{ height: `${d.value}%` }} />
                    <div className="bc-label">{d.day}</div>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState
                icon="📊"
                title="No performance data yet"
                message="Once students submit exams, weekly trends will appear here."
              />
            )}
          </div>
        </Card>

        <Card>
          <CardHead title="Upcoming exams" subtitle="Scheduled in the next 7 days" />
          <div style={{ padding: "8px 16px 16px" }}>
            {UPCOMING.length > 0 ? (
              <div style={{ display: "grid", gap: 10 }}>
                {UPCOMING.map((u) => (
                  <div
                    key={u.title}
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      padding: 12,
                      background: "var(--surface-2)",
                      borderRadius: 10,
                    }}
                  >
                    <div>
                      <div className="cell-strong">{u.title}</div>
                      <div style={{ fontSize: 12, color: "var(--muted)" }}>{u.when}</div>
                    </div>
                    <Badge tone="info">{u.count} students</Badge>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState
                icon="🗓️"
                title="Nothing scheduled"
                message="Create an exam and schedule it to see it listed here."
              />
            )}
          </div>
        </Card>
      </div>

      <Card className="mt-18">
        <CardHead
          title="Recent activity"
          subtitle="Last 10 events from your portal"
          right={<button className="btn btn-ghost">View all</button>}
        />
        {RECENT_ACTIVITY.length > 0 ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Student</th>
                  <th>Exam</th>
                  <th>Score</th>
                  <th>Status</th>
                  <th>Submitted</th>
                </tr>
              </thead>
              <tbody>
                {RECENT_ACTIVITY.map((r) => (
                  <tr key={r.id} className="row-hover">
                    <td>
                      <div className="user-cell">
                        <Avatar initials={r.initials} gradient={r.grad} size="sm" />
                        <div>
                          <div className="cell-strong">{r.name}</div>
                          <div style={{ fontSize: 11.5, color: "var(--muted)" }}>{r.roll}</div>
                        </div>
                      </div>
                    </td>
                    <td>{r.exam}</td>
                    <td className="cell-strong">{r.score}</td>
                    <td>
                      <Badge tone={r.status} showDot>{r.statusLabel}</Badge>
                    </td>
                    <td>{r.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon="📭"
            title="No activity yet"
            message="Student submissions will appear here in real-time."
          />
        )}
      </Card>
    </>
  );
}
