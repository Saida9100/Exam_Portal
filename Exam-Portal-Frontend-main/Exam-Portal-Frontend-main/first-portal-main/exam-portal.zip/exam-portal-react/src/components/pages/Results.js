import React from "react";
import { Card, CardHead } from "../ui/Card";
import Badge from "../ui/Badge";
import EmptyState from "../ui/EmptyState";
import { RESULTS } from "../../data/mock";

export default function Results() {
  return (
    <>
      <div className="result-summary">
        <div className="rs-item">
          <div className="lbl">Total submissions</div>
          <div className="val">{RESULTS.length || "—"}</div>
        </div>
        <div className="rs-item">
          <div className="lbl">Average score</div>
          <div className="val">—</div>
        </div>
        <div className="rs-item">
          <div className="lbl">Pass percentage</div>
          <div className="val" style={{ color: "var(--success)" }}>—</div>
        </div>
      </div>

      <Card>
        <CardHead
          title="Exam Results"
          subtitle="Ranked by score, descending"
          right={
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn btn-outline">⬇️ Export PDF</button>
              <button className="btn btn-outline">⬇️ Export Excel</button>
            </div>
          }
        />
        {RESULTS.length > 0 ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Student</th>
                  <th>Roll No.</th>
                  <th>Score</th>
                  <th>Time taken</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {RESULTS.map((r) => (
                  <tr key={r.roll} className="row-hover">
                    <td className="cell-strong">{r.rank}</td>
                    <td>{r.name}</td>
                    <td>{r.roll}</td>
                    <td className={r.tone === "success" ? "cell-strong" : ""}>{r.score}</td>
                    <td>{r.time}</td>
                    <td><Badge tone={r.tone}>{r.status}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon="📈"
            title="No results yet"
            message="Once students submit their exams, the leaderboard and analytics will appear here."
          />
        )}
      </Card>
    </>
  );
}
