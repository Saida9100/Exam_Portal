import React, { useRef, useState } from "react";
import { Card, CardHead } from "../ui/Card";
import Badge from "../ui/Badge";
import EmptyState from "../ui/EmptyState";
import { useData } from "../../data/DataContext";
import { useAuth } from "../../auth/AuthContext";

const PDF_CATEGORIES = ["Question Paper", "Reference Material", "Answer Key", "Instructions", "Other"];

function fileSize(kb) {
  if (kb >= 1024) return `${(kb / 1024).toFixed(2)} MB`;
  return `${kb} KB`;
}

export default function CreateExam() {
  const { addPdf, pdfs } = useData();
  const { user } = useAuth();

  const [meta, setMeta] = useState({
    title: "",
    subject: "",
    duration: 60,
    marks: 50,
    start: "",
    end: "",
    instructions: "",
  });

  const [questions, setQuestions] = useState([]);

  // -------- PDF upload (attached to this exam) --------
  const [attached, setAttached] = useState([]); // { id, title, filename, sizeKB, category, dataUrl }
  const [pdfTitle, setPdfTitle] = useState("");
  const [pdfCategory, setPdfCategory] = useState(PDF_CATEGORIES[0]);
  const [pdfFile, setPdfFile] = useState(null);
  const [pdfError, setPdfError] = useState("");
  const [pdfSuccess, setPdfSuccess] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const pdfInputRef = useRef(null);

  const updateMeta = (k, v) => setMeta((m) => ({ ...m, [k]: v }));

  const addQuestion = () =>
    setQuestions((q) => [
      ...q,
      { id: Date.now(), text: "", options: ["", "", "", ""], correct: 0, marks: 1 },
    ]);
  const removeQuestion = (id) => setQuestions((q) => q.filter((x) => x.id !== id));
  const updateQ = (id, patch) =>
    setQuestions((q) => q.map((x) => (x.id === id ? { ...x, ...patch } : x)));

  // -------- PDF helpers --------
  const onChoosePdf = (f) => {
    setPdfError("");
    setPdfSuccess("");
    if (!f) return;
    if (f.type !== "application/pdf") {
      setPdfError("Only PDF files are accepted.");
      return;
    }
    if (f.size > 10 * 1024 * 1024) {
      setPdfError("File is larger than 10 MB. Please upload a smaller PDF.");
      return;
    }
    setPdfFile(f);
    if (!pdfTitle) setPdfTitle(f.name.replace(/\.pdf$/i, ""));
  };

  const uploadPdf = () => {
    setPdfError("");
    setPdfSuccess("");
    if (!pdfFile) {
      setPdfError("Please choose a PDF first.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const newDoc = {
        id: `xpdf-${Date.now()}`,
        title: pdfTitle || pdfFile.name,
        filename: pdfFile.name,
        sizeKB: Math.round(pdfFile.size / 1024),
        category: pdfCategory,
        dataUrl: reader.result,
      };
      setAttached((a) => [newDoc, ...a]);
      // also push to the global PDF library so it appears under "PDF Library"
      addPdf({
        title: `${meta.title || "Untitled exam"} — ${newDoc.title}`,
        file: pdfFile,
        category: pdfCategory,
        dataUrl: reader.result,
        uploadedBy: user?.name || "—",
      });
      setPdfSuccess(`✓ "${newDoc.title}" attached to this exam.`);
      setPdfFile(null);
      setPdfTitle("");
      setPdfCategory(PDF_CATEGORIES[0]);
      if (pdfInputRef.current) pdfInputRef.current.value = "";
    };
    reader.readAsDataURL(pdfFile);
  };

  const removeAttached = (id) => setAttached((a) => a.filter((x) => x.id !== id));

  return (
    <>
      {/* ============ EXAM META ============ */}
      <Card>
        <CardHead
          title="Create new exam"
          subtitle="Define the basics, then add your questions and attach PDFs."
          right={
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn btn-outline">Save as draft</button>
              <button className="btn btn-primary">Publish exam</button>
            </div>
          }
        />
        <div className="card-pad">
          <div className="form-row">
            <div className="field">
              <label>Exam title</label>
              <input
                placeholder="e.g. Database Management Mid-term"
                value={meta.title}
                onChange={(e) => updateMeta("title", e.target.value)}
              />
            </div>
            <div className="field">
              <label>Subject / Course</label>
              <input
                placeholder="e.g. CS304 - DBMS"
                value={meta.subject}
                onChange={(e) => updateMeta("subject", e.target.value)}
              />
            </div>
          </div>
          <div className="form-row">
            <div className="field">
              <label>Duration (minutes)</label>
              <input
                type="number"
                value={meta.duration}
                onChange={(e) => updateMeta("duration", e.target.value)}
              />
            </div>
            <div className="field">
              <label>Total marks</label>
              <input
                type="number"
                value={meta.marks}
                onChange={(e) => updateMeta("marks", e.target.value)}
              />
            </div>
          </div>
          <div className="form-row">
            <div className="field">
              <label>Start date &amp; time</label>
              <input
                type="datetime-local"
                value={meta.start}
                onChange={(e) => updateMeta("start", e.target.value)}
              />
            </div>
            <div className="field">
              <label>End date &amp; time</label>
              <input
                type="datetime-local"
                value={meta.end}
                onChange={(e) => updateMeta("end", e.target.value)}
              />
            </div>
          </div>
          <div className="field">
            <label>Instructions for students</label>
            <textarea
              rows={3}
              placeholder="Read each question carefully. AI proctoring is enabled."
              value={meta.instructions}
              onChange={(e) => updateMeta("instructions", e.target.value)}
            />
          </div>

          <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginTop: 6 }}>
            <label className="check"><input type="checkbox" defaultChecked /> Enable AI proctoring (webcam)</label>
            <label className="check"><input type="checkbox" defaultChecked /> Shuffle questions per student</label>
            <label className="check"><input type="checkbox" /> Allow review before submit</label>
            <label className="check"><input type="checkbox" defaultChecked /> Auto-submit on time-up</label>
          </div>
        </div>
      </Card>

      {/* ============ PDF ATTACHMENTS ============ */}
      <Card className="mt-18">
        <CardHead
          title="📎 Attach PDF documents to this exam"
          subtitle="Upload the question paper, reference notes, instructions or answer key (PDF only, max 10 MB)."
          right={
            <Badge tone={attached.length > 0 ? "success" : "muted"}>
              {attached.length} attached
            </Badge>
          }
        />
        <div className="card-pad">
          {pdfError && (
            <div
              className="alert"
              style={{
                background: "var(--danger-soft)",
                color: "#991b1b",
                borderColor: "#fecaca",
                marginBottom: 14,
              }}
            >
              <div>⚠️</div>
              <div>{pdfError}</div>
            </div>
          )}
          {pdfSuccess && (
            <div
              className="alert"
              style={{
                background: "var(--success-soft)",
                color: "#166534",
                borderColor: "#bbf7d0",
                marginBottom: 14,
              }}
            >
              <div>✅</div>
              <div>{pdfSuccess}</div>
            </div>
          )}

          {/* Drop zone */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              onChoosePdf(e.dataTransfer.files?.[0]);
            }}
            onClick={() => pdfInputRef.current?.click()}
            style={{
              border: `2px dashed ${dragOver ? "var(--brand)" : "#cbd5e1"}`,
              background: dragOver ? "var(--brand-soft)" : "var(--surface-2)",
              borderRadius: 14,
              padding: "28px 20px",
              textAlign: "center",
              cursor: "pointer",
              transition: "all .15s",
              marginBottom: 14,
            }}
          >
            <div style={{ fontSize: 32 }}>📄</div>
            <div style={{ fontSize: 14, fontWeight: 700, marginTop: 6 }}>
              {pdfFile ? pdfFile.name : "Click to choose, or drag & drop a PDF here"}
            </div>
            <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 4 }}>
              Only PDF • Max 10 MB
              {pdfFile && <> &nbsp;•&nbsp; {fileSize(Math.round(pdfFile.size / 1024))}</>}
            </div>
            <input
              ref={pdfInputRef}
              type="file"
              accept="application/pdf"
              style={{ display: "none" }}
              onChange={(e) => onChoosePdf(e.target.files?.[0])}
            />
          </div>

          <div className="form-row">
            <div className="field">
              <label>Document title</label>
              <input
                placeholder="e.g. DBMS Mid-term — Question Paper"
                value={pdfTitle}
                onChange={(e) => setPdfTitle(e.target.value)}
              />
            </div>
            <div className="field">
              <label>Category</label>
              <select value={pdfCategory} onChange={(e) => setPdfCategory(e.target.value)}>
                {PDF_CATEGORIES.map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginBottom: 4 }}>
            <button
              type="button"
              className="btn btn-outline"
              onClick={() => {
                setPdfFile(null);
                setPdfTitle("");
                setPdfCategory(PDF_CATEGORIES[0]);
                setPdfError("");
                setPdfSuccess("");
                if (pdfInputRef.current) pdfInputRef.current.value = "";
              }}
            >
              Clear
            </button>
            <button
              type="button"
              className="btn btn-primary"
              onClick={uploadPdf}
              disabled={!pdfFile}
            >
              ⬆️ Attach PDF
            </button>
          </div>

          {/* Attached list */}
          {attached.length > 0 && (
            <div style={{ marginTop: 18 }}>
              <div
                style={{
                  fontSize: 12,
                  color: "var(--muted)",
                  fontWeight: 700,
                  textTransform: "uppercase",
                  letterSpacing: ".5px",
                  marginBottom: 8,
                }}
              >
                Attached to this exam
              </div>
              <div style={{ display: "grid", gap: 8 }}>
                {attached.map((p) => (
                  <div
                    key={p.id}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 12,
                      padding: "10px 14px",
                      background: "var(--surface-2)",
                      border: "1px solid var(--line)",
                      borderRadius: 10,
                    }}
                  >
                    <div style={{ fontSize: 22 }}>📄</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div
                        className="cell-strong"
                        style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}
                      >
                        {p.title}
                      </div>
                      <div style={{ fontSize: 11.5, color: "var(--muted)" }}>
                        {p.filename} • {fileSize(p.sizeKB)} • {p.category}
                      </div>
                    </div>
                    <Badge tone="info">{p.category}</Badge>
                    <a className="ghost-link" href={p.dataUrl} target="_blank" rel="noreferrer">
                      View
                    </a>
                    <a className="ghost-link" href={p.dataUrl} download={p.filename}>
                      Download
                    </a>
                    <button
                      className="ghost-link"
                      style={{ color: "var(--danger)" }}
                      onClick={() => removeAttached(p.id)}
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
              <div style={{ fontSize: 11.5, color: "var(--muted)", marginTop: 8 }}>
                💡 Uploaded PDFs also appear under <strong>Manage → PDF Library</strong> ({pdfs.length} total).
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* ============ QUESTIONS ============ */}
      <Card className="mt-18">
        <CardHead
          title="Questions"
          subtitle="Add MCQs, descriptive or coding questions."
          right={
            <button className="btn btn-primary" onClick={addQuestion}>
              + Add Question
            </button>
          }
        />
        <div className="card-pad">
          {questions.length === 0 ? (
            <EmptyState
              icon="❓"
              title="No questions added"
              message="Click 'Add Question' to start building your question paper, or attach a PDF question paper above."
              action={
                <button className="btn btn-primary" onClick={addQuestion}>
                  + Add your first question
                </button>
              }
            />
          ) : (
            <>
              {questions.map((q, i) => (
                <div key={q.id} className="question-builder">
                  <div className="qb-head">
                    <Badge>Question {i + 1} • MCQ • {q.marks} marks</Badge>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button className="btn btn-ghost">✎ Edit</button>
                      <button
                        className="btn btn-ghost"
                        style={{ color: "var(--danger)" }}
                        onClick={() => removeQuestion(q.id)}
                      >
                        🗑 Delete
                      </button>
                    </div>
                  </div>
                  <div className="field">
                    <label>Question</label>
                    <input
                      placeholder="Type the question here…"
                      value={q.text}
                      onChange={(e) => updateQ(q.id, { text: e.target.value })}
                    />
                  </div>
                  <div className="form-row">
                    {q.options.slice(0, 2).map((o, idx) => (
                      <div key={idx} className="field">
                        <label>Option {String.fromCharCode(65 + idx)}</label>
                        <input
                          placeholder={`Option ${String.fromCharCode(65 + idx)}`}
                          value={o}
                          onChange={(e) => {
                            const opts = [...q.options];
                            opts[idx] = e.target.value;
                            updateQ(q.id, { options: opts });
                          }}
                        />
                      </div>
                    ))}
                  </div>
                  <div className="form-row">
                    {q.options.slice(2, 4).map((o, idx) => (
                      <div key={idx + 2} className="field">
                        <label>Option {String.fromCharCode(65 + idx + 2)}</label>
                        <input
                          placeholder={`Option ${String.fromCharCode(65 + idx + 2)}`}
                          value={o}
                          onChange={(e) => {
                            const opts = [...q.options];
                            opts[idx + 2] = e.target.value;
                            updateQ(q.id, { options: opts });
                          }}
                        />
                      </div>
                    ))}
                  </div>
                  <div className="field">
                    <label>Correct answer</label>
                    <select
                      value={q.correct}
                      onChange={(e) => updateQ(q.id, { correct: +e.target.value })}
                    >
                      {q.options.map((o, idx) => (
                        <option key={idx} value={idx}>
                          Option {String.fromCharCode(65 + idx)} {o ? `— ${o}` : ""}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              ))}

              <div
                className="question-builder"
                style={{ background: "#fff", borderStyle: "dashed", cursor: "pointer" }}
                onClick={addQuestion}
              >
                <div style={{ textAlign: "center", padding: 14, color: "var(--muted)" }}>
                  + Click here to insert another question
                </div>
              </div>
            </>
          )}
        </div>
      </Card>
    </>
  );
}
