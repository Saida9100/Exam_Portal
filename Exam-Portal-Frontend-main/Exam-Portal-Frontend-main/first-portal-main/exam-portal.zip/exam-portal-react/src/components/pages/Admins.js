import React, { useState } from "react";
import { Card, CardHead } from "../ui/Card";
import Avatar from "../ui/Avatar";
import Badge from "../ui/Badge";
import EmptyState from "../ui/EmptyState";
import Modal from "../ui/Modal";
import { useData } from "../../data/DataContext";
import { useAuth } from "../../auth/AuthContext";

/** Super-admin-only page to create / delete Admin accounts */
export default function Admins() {
  const { admins, addAdmin, removeAdmin } = useData();
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ name: "", email: "", password: "" });

  const update = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = (e) => {
    e.preventDefault();
    setError("");
    if (form.password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    const res = addAdmin(form);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    setForm({ name: "", email: "", password: "" });
    setOpen(false);
  };

  return (
    <>
      <div className="toolbar">
        <div style={{ fontSize: 13, color: "var(--muted)" }}>
          Showing {admins.length} admin{admins.length === 1 ? "" : "s"} •
          Signed in as <strong style={{ color: "var(--ink-2)" }}>{user?.name}</strong>
        </div>
        <div className="right">
          <button className="btn btn-primary" onClick={() => setOpen(true)}>
            + Create Admin Account
          </button>
        </div>
      </div>

      <Card>
        <CardHead
          title="Admin accounts"
          subtitle="Only Super Admins can create or remove Admin accounts."
        />
        {admins.length > 0 ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Admin</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Created</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {admins.map((a) => (
                  <tr key={a.id} className="row-hover">
                    <td>
                      <div className="user-cell">
                        <Avatar initials={a.initials} gradient={a.gradient} size="sm" />
                        <span className="cell-strong">{a.name}</span>
                      </div>
                    </td>
                    <td>{a.email}</td>
                    <td><Badge>Admin</Badge></td>
                    <td>{a.createdAt}</td>
                    <td>
                      <button
                        className="ghost-link"
                        style={{ color: "var(--danger)" }}
                        onClick={() => {
                          if (window.confirm(`Delete admin "${a.name}"?`)) removeAdmin(a.id);
                        }}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon="🛡️"
            title="No admins yet"
            message="Create the first admin account to delegate exam management."
            action={
              <button className="btn btn-primary" onClick={() => setOpen(true)}>
                + Create Admin Account
              </button>
            }
          />
        )}
      </Card>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Create new Admin"
        subtitle="The new admin can sign in immediately using these credentials."
      >
        <form onSubmit={submit}>
          {error && (
            <div
              className="alert"
              style={{
                background: "var(--danger-soft)",
                color: "#991b1b",
                borderColor: "#fecaca",
                marginBottom: 14,
              }}
            >
              <div>⚠️</div>
              <div>{error}</div>
            </div>
          )}

          <div className="field">
            <label>Full name *</label>
            <input
              placeholder="e.g. Jane Doe"
              value={form.name}
              onChange={(e) => update("name", e.target.value)}
              required
            />
          </div>
          <div className="field">
            <label>Email *</label>
            <input
              type="email"
              placeholder="admin.name@yourinstitution.edu"
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              required
            />
          </div>
          <div className="field">
            <label>Password * <span style={{ fontWeight: 400, color: "var(--muted)" }}>(min 6 chars)</span></label>
            <input
              type="text"
              placeholder="Strong password"
              value={form.password}
              onChange={(e) => update("password", e.target.value)}
              required
              minLength={6}
            />
          </div>

          <div className="field-help" style={{ marginBottom: 14 }}>
            Share the credentials securely. The admin should change the password
            after first login.
          </div>

          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
            <button type="button" className="btn btn-outline" onClick={() => setOpen(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              ✓ Create admin
            </button>
          </div>
        </form>
      </Modal>
    </>
  );
}
