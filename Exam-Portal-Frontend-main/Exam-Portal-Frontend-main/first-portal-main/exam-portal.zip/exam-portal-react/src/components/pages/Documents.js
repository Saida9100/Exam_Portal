import React, { useRef, useState } from "react";
import { Card, CardHead } from "../ui/Card";
import Badge from "../ui/Badge";
import EmptyState from "../ui/EmptyState";
import { useData } from "../../data/DataContext";
import { useAuth } from "../../auth/AuthContext";

const CATEGORIES = ["Exam Paper", "Question Bank", "Study Material", "Answer Key", "Other"];

function fileSize(kb) {
  if (kb >= 1024) return `${(kb / 1024).toFixed(2)} MB`;
  return `${kb} KB`;
}

/** PDF upload + library — available to both Super Admin and Admin */
export default function Documents() {
  const { pdfs, addPdf, removePdf } = useData();
  const { user } = useAuth();
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [file, setFile] = useState(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef(null);

  const onChooseFile = (f) => {
    setError("");
    setSuccess("");
    if (!f) return;
    if (f.type !== "application/pdf") {
      setError("Only PDF files are accepted.");
      return;
    }
    if (f.size > 10 * 1024 * 1024) {
      setError("File is larger than 10 MB. Please upload a smaller PDF.");
      return;
    }
    setFile(f);
    if (!title) setTitle(f.name.replace(/\.pdf$/i, ""));
  };

  const submit = (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    if (!file) {
      setError("Please select a PDF first.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      addPdf({
        title: title || file.name,
        file,
        category,
        dataUrl: reader.result, // base64 in-memory so we can preview/download immediately
        uploadedBy: user?.name || "—",
      });
      setSuccess(`✓ "${title || file.name}" uploaded successfully.`);
      setFile(null);
      setTitle("");
      setCategory(CATEGORIES[0]);
      if (inputRef.current) inputRef.current.value = "";
    };
    reader.readAsDataURL(file);
  };

  return (
    <>
      <Card className="mb-18">
        <CardHead
          title="Upload a PDF document"
          subtitle="Upload exam papers, question banks, study material or answer keys (max 10 MB)."
        />
        <div className="card-pad">
          <form onSubmit={submit}>
            {error && (
              <div
                className="alert"
                style={{
                  background: "var(--danger-soft)",
                  color: "#991b1b",
                  borderColor: "#fecaca",
                  marginBottom: 14,
                }}
              >
                <div>⚠️</div>
                <div>{error}</div>
              </div>
            )}
            {success && (
              <div
                className="alert"
                style={{
                  background: "var(--success-soft)",
                  color: "#166534",
                  borderColor: "#bbf7d0",
                  marginBottom: 14,
                }}
              >
                <div>✅</div>
                <div>{success}</div>
              </div>
            )}

            {/* Drop zone */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                onChooseFile(e.dataTransfer.files?.[0]);
              }}
              onClick={() => inputRef.current?.click()}
              style={{
                border: `2px dashed ${dragOver ? "var(--brand)" : "#cbd5e1"}`,
                background: dragOver ? "var(--brand-soft)" : "var(--surface-2)",
                borderRadius: 14,
                padding: "32px 20px",
                textAlign: "center",
                cursor: "pointer",
                transition: "all .15s",
                marginBottom: 16,
              }}
            >
              <div style={{ fontSize: 36 }}>📄</div>
              <div style={{ fontSize: 15, fontWeight: 700, marginTop: 6 }}>
                {file ? file.name : "Click to choose, or drag & drop a PDF here"}
              </div>
              <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 4 }}>
                Only PDF files • Max 10 MB
                {file && <> &nbsp;•&nbsp; {fileSize(Math.round(file.size / 1024))}</>}
              </div>
              <input
                ref={inputRef}
                type="file"
                accept="application/pdf"
                style={{ display: "none" }}
                onChange={(e) => onChooseFile(e.target.files?.[0])}
              />
            </div>

            <div className="form-row">
              <div className="field">
                <label>Document title</label>
                <input
                  placeholder="e.g. DBMS Mid-term — Question Paper"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>
              <div className="field">
                <label>Category</label>
                <select value={category} onChange={(e) => setCategory(e.target.value)}>
                  {CATEGORIES.map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </div>
            </div>

            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => {
                  setFile(null);
                  setTitle("");
                  setCategory(CATEGORIES[0]);
                  setError("");
                  setSuccess("");
                  if (inputRef.current) inputRef.current.value = "";
                }}
              >
                Clear
              </button>
              <button type="submit" className="btn btn-primary" disabled={!file}>
                ⬆️ Upload PDF
              </button>
            </div>
          </form>
        </div>
      </Card>

      <Card>
        <CardHead
          title="Uploaded documents"
          subtitle={`${pdfs.length} document${pdfs.length === 1 ? "" : "s"} in your library`}
        />
        {pdfs.length > 0 ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Category</th>
                  <th>File</th>
                  <th>Size</th>
                  <th>Uploaded by</th>
                  <th>When</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {pdfs.map((p) => (
                  <tr key={p.id} className="row-hover">
                    <td className="cell-strong">📄 {p.title}</td>
                    <td><Badge tone="info">{p.category}</Badge></td>
                    <td>{p.filename}</td>
                    <td>{fileSize(p.sizeKB)}</td>
                    <td>{p.uploadedBy}</td>
                    <td>{p.uploadedAt}</td>
                    <td>
                      <div style={{ display: "flex", gap: 8 }}>
                        {p.dataUrl ? (
                          <>
                            <a
                              className="ghost-link"
                              href={p.dataUrl}
                              target="_blank"
                              rel="noreferrer"
                            >
                              View
                            </a>
                            <a
                              className="ghost-link"
                              href={p.dataUrl}
                              download={p.filename}
                            >
                              Download
                            </a>
                          </>
                        ) : (
                          <span style={{ color: "var(--muted)", fontSize: 12 }}>
                            (preview unavailable after refresh)
                          </span>
                        )}
                        <button
                          className="ghost-link"
                          style={{ color: "var(--danger)" }}
                          onClick={() => {
                            if (window.confirm(`Delete "${p.title}"?`)) removePdf(p.id);
                          }}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon="📚"
            title="No PDFs uploaded yet"
            message="Upload your first exam paper or study material using the panel above."
          />
        )}
      </Card>
    </>
  );
}
