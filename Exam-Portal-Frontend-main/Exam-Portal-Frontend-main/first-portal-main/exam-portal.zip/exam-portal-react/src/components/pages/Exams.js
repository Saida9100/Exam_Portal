import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card } from "../ui/Card";
import Badge from "../ui/Badge";
import EmptyState from "../ui/EmptyState";
import { useAuth } from "../../auth/AuthContext";
import { EXAMS } from "../../data/mock";

const TABS = ["All exams", "Published", "Draft", "Archived"];

export default function Exams() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [tab, setTab] = useState("All exams");

  const canCreate = user?.role === "admin" || user?.role === "superadmin";

  const visible =
    tab === "All exams"
      ? EXAMS
      : EXAMS.filter((e) => e.status.toLowerCase() === tab.toLowerCase());

  return (
    <>
      <div className="toolbar">
        <div className="pill-tabs">
          {TABS.map((t) => (
            <button key={t} className={tab === t ? "active" : ""} onClick={() => setTab(t)}>
              {t}
            </button>
          ))}
        </div>
        <div className="right">
          <button className="btn btn-outline">⬇️ Export</button>
          {canCreate && (
            <button className="btn btn-primary" onClick={() => navigate("/app/create")}>
              + Create Exam
            </button>
          )}
        </div>
      </div>

      <Card>
        {visible.length > 0 ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Exam title</th>
                  <th>Subject</th>
                  <th>Duration</th>
                  <th>Questions</th>
                  <th>Scheduled</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {visible.map((e) => (
                  <tr key={e.id} className="row-hover">
                    <td className="cell-strong">{e.title}</td>
                    <td>{e.subject}</td>
                    <td>{e.duration}</td>
                    <td>{e.questions}</td>
                    <td>{e.schedule}</td>
                    <td><Badge tone={e.tone}>{e.status}</Badge></td>
                    <td>
                      <button className="ghost-link" onClick={() => navigate("/app/taking")}>
                        {canCreate ? "Manage" : "Take exam"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon="📝"
            title="No exams yet"
            message={
              canCreate
                ? "Create your first exam to get started. You can add MCQ, descriptive or coding questions."
                : "No exams have been assigned to you yet. Please check back later."
            }
            action={
              canCreate ? (
                <button className="btn btn-primary" onClick={() => navigate("/app/create")}>
                  + Create your first exam
                </button>
              ) : null
            }
          />
        )}
      </Card>
    </>
  );
}
