import React from "react";
import { Outlet, useLocation } from "react-router-dom";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";

const META = {
  "/app/dashboard": { title: "Dashboard", crumbs: "Home / Dashboard" },
  "/app/exams": { title: "Exams", crumbs: "Home / Exams" },
  "/app/create": { title: "Create Exam", crumbs: "Home / Exams / Create" },
  "/app/taking": { title: "Live Exam — Student View", crumbs: "Home / Live Exam" },
  "/app/proctor": { title: "Proctoring Monitor", crumbs: "Home / Proctoring" },
  "/app/results": { title: "Results & Analytics", crumbs: "Home / Results" },
  "/app/students": { title: "Students", crumbs: "Home / Manage / Students" },
  "/app/admins": { title: "Admin Accounts", crumbs: "Home / Manage / Admins" },
  "/app/documents": { title: "PDF Library", crumbs: "Home / Manage / Documents" },
  "/app/settings": { title: "Settings", crumbs: "Home / Manage / Settings" },
};

export default function AppLayout() {
  const { pathname } = useLocation();
  const meta = META[pathname] || { title: "ExamPortal", crumbs: "Home" };

  return (
    <div className="app">
      <Sidebar />
      <div className="main">
        <Topbar title={meta.title} crumbs={meta.crumbs} />
        <div className="content">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
