import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import Icon from "./ui/Icon";
import Avatar from "./ui/Avatar";
import { useAuth } from "../auth/AuthContext";

// Each item lists the roles allowed to see it.
const NAV_MAIN = [
  { to: "/app/dashboard", label: "Dashboard",   icon: "dashboard", roles: ["superadmin", "admin", "student"] },
  { to: "/app/exams",     label: "Exams",       icon: "exam",      roles: ["superadmin", "admin", "student"] },
  { to: "/app/create",    label: "Create Exam", icon: "plus",      roles: ["superadmin", "admin"] },
  { to: "/app/taking",    label: "Live Exam",   icon: "clock",     roles: ["superadmin", "admin", "student"] },
  { to: "/app/proctor",   label: "Proctoring",  icon: "camera",    roles: ["superadmin", "admin"] },
  { to: "/app/results",   label: "Results & Analytics", icon: "chart", roles: ["superadmin", "admin", "student"] },
];
const NAV_MANAGE = [
  { to: "/app/students",  label: "Students",    icon: "users",     roles: ["superadmin", "admin"] },
  { to: "/app/admins",    label: "Admin Accounts", icon: "users",  roles: ["superadmin"] },
  { to: "/app/documents", label: "PDF Library", icon: "exam",      roles: ["superadmin", "admin"] },
  { to: "/app/settings",  label: "Settings",    icon: "settings",  roles: ["superadmin"] },
];

function roleLabel(role) {
  if (role === "superadmin") return "Super Admin Console";
  if (role === "admin") return "Admin Console";
  return "Student Portal";
}

export default function Sidebar() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const role = user?.role || "student";

  const filter = (items) => items.filter((i) => i.roles.includes(role));

  const handleLogout = () => {
    logout();
    navigate("/login", { replace: true });
  };

  return (
    <aside className="sidebar">
      <div className="sb-brand">
        <div className="sb-logo">EP</div>
        <div className="sb-brand-text">
          ExamPortal
          <small>v2.0 • {roleLabel(role)}</small>
        </div>
      </div>

      <div className="sb-section">Main</div>
      {filter(NAV_MAIN).map((n) => (
        <NavLink
          key={n.to}
          to={n.to}
          className={({ isActive }) => `sb-link ${isActive ? "active" : ""}`}
        >
          <Icon name={n.icon} />
          {n.label}
        </NavLink>
      ))}

      {filter(NAV_MANAGE).length > 0 && (
        <>
          <div className="sb-section">Manage</div>
          {filter(NAV_MANAGE).map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              className={({ isActive }) => `sb-link ${isActive ? "active" : ""}`}
            >
              <Icon name={n.icon} />
              {n.label}
            </NavLink>
          ))}
        </>
      )}

      <div className="sb-footer">
        <Avatar initials={user?.initials || "U"} gradient={user?.gradient || "#6366f1,#22d3ee"} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ color: "#fff", fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
            {user?.name || "Guest"}
          </div>
          <div style={{ fontSize: 11, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
            {user?.email || ""}
          </div>
        </div>
        <button
          className="icon-btn"
          style={{ background: "transparent", color: "#94a3b8", width: 32, height: 32 }}
          onClick={handleLogout}
          title="Logout"
        >
          <Icon name="logout" size={16} />
        </button>
      </div>
    </aside>
  );
}
