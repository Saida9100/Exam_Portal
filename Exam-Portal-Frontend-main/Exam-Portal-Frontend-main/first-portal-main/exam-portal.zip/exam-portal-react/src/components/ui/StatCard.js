import React from "react";
import Icon from "./Icon";
import { Card } from "./Card";

export default function StatCard({ label, value, delta, deltaDown, icon, tone }) {
  return (
    <Card className="card-pad">
      <div className="stat">
        <div>
          <div className="label">{label}</div>
          <div className="value">{value}</div>
          {delta && <div className={`delta ${deltaDown ? "down" : ""}`}>{delta}</div>}
        </div>
        <div className={`ico ${tone || ""}`}>
          <Icon name={icon} size={22} />
        </div>
      </div>
    </Card>
  );
}
