import React from "react";

/**
 * Friendly "no data yet" placeholder used by every page that depends on data.
 *
 *   <EmptyState
 *     icon="📭"
 *     title="No exams yet"
 *     message="Create your first exam to see it listed here."
 *     action={<button className="btn btn-primary">+ Create Exam</button>}
 *   />
 */
export default function EmptyState({ icon = "📭", title, message, action }) {
  return (
    <div
      style={{
        padding: "60px 24px",
        textAlign: "center",
        color: "var(--muted)",
      }}
    >
      <div style={{ fontSize: 44, marginBottom: 10 }}>{icon}</div>
      <div
        style={{
          fontSize: 16,
          fontWeight: 700,
          color: "var(--ink)",
          marginBottom: 6,
        }}
      >
        {title}
      </div>
      {message && (
        <div style={{ fontSize: 13, maxWidth: 460, margin: "0 auto 16px" }}>
          {message}
        </div>
      )}
      {action}
    </div>
  );
}
