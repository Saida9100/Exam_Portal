import React from "react";

export default function Badge({ tone = "", showDot = false, children }) {
  return (
    <span className={`badge ${tone}`}>
      {showDot && <span className="dot" />}
      {children}
    </span>
  );
}
