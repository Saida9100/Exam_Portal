import React from "react";

export default function Avatar({ initials = "U", gradient = "#6366f1,#22d3ee", size = "" }) {
  return (
    <div
      className={`avatar ${size}`}
      style={{ background: `linear-gradient(135deg, ${gradient})` }}
    >
      {initials}
    </div>
  );
}
