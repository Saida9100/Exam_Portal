import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "./AuthContext";

/**
 * Wrap a route to require a logged-in user.
 * Optionally restrict by role(s):  <RequireAuth roles={["admin","superadmin"]}> ... </RequireAuth>
 */
export default function RequireAuth({ children, roles }) {
  const { user, ready } = useAuth();
  const location = useLocation();

  if (!ready) return null; // tiny loading state

  if (!user) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  if (roles && !roles.includes(user.role)) {
    return <Navigate to="/app/dashboard" replace />;
  }

  return children;
}
