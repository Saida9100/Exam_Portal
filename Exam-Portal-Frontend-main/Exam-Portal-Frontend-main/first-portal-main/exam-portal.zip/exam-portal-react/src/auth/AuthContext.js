import React, { createContext, useContext, useEffect, useState } from "react";
import {
  authenticate,
  loadSession,
  saveSession,
  clearSession,
} from "../data/auth";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setUser(loadSession());
    setReady(true);
  }, []);

  const login = (email, password) => {
    const found = authenticate(email, password);
    if (!found) return { ok: false, error: "Invalid email or password." };
    const safe = { ...found };
    delete safe.password; // never keep password in memory/storage
    saveSession(safe);
    setUser(safe);
    return { ok: true, user: safe };
  };

  const logout = () => {
    clearSession();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, ready }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
