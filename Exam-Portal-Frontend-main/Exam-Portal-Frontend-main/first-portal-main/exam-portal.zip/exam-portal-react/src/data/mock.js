// =====================================================================
//  Data sources — empty by default. Wire to your real API later.
//  Every page imports from here so swapping to fetch/Axios is trivial.
// =====================================================================

export const KPIS = [];
export const WEEK_PERF = [];
export const UPCOMING = [];
export const RECENT_ACTIVITY = [];
export const EXAMS = [];
export const QUESTIONS = [];
export const PROCTOR_FLAGS = [];
export const RESULTS = [];
export const STUDENTS = [];
export const PALETTE = [];
