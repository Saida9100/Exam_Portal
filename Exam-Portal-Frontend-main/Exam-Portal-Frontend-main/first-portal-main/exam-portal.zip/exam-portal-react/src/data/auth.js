// =====================================================================
//  Demo login credentials + simple in-memory user store
//  Replace with your real auth API in production
// =====================================================================
//
//  Super Admin → full access (everything + Settings + manage Admins)
//  Admin       → can manage exams, students, view proctoring & results
//  Student     → can only view their own exams, take exam, view results
//
// =====================================================================

let USERS = [
  {
    id: "u-super",
    role: "superadmin",
    name: "Super Admin",
    email: "superadmin@examportal.com",
    password: "Super@123",
    initials: "SA",
    gradient: "#ef4444,#f59e0b",
    createdAt: "2026-01-01",
  },
  {
    id: "u-admin",
    role: "admin",
    name: "Admin User",
    email: "admin@examportal.com",
    password: "Admin@123",
    initials: "AD",
    gradient: "#6366f1,#22d3ee",
    createdAt: "2026-01-15",
  },
  {
    id: "u-student",
    role: "student",
    name: "Student User",
    email: "student@examportal.com",
    password: "Student@123",
    initials: "ST",
    gradient: "#22c55e,#06b6d4",
    createdAt: "2026-02-01",
  },
];

export const DEMO_CREDENTIALS = [
  { role: "superadmin", label: "Super Admin", email: "superadmin@examportal.com", password: "Super@123" },
  { role: "admin",      label: "Admin",       email: "admin@examportal.com",      password: "Admin@123" },
  { role: "student",    label: "Student",     email: "student@examportal.com",    password: "Student@123" },
];

const STORAGE_KEY = "examportal_user";

// ----------- helpers used by AuthContext -----------
export function authenticate(email, password) {
  return (
    USERS.find(
      (u) =>
        u.email.toLowerCase() === email.trim().toLowerCase() &&
        u.password === password
    ) || null
  );
}

export function saveSession(user) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
}
export function loadSession() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}
export function clearSession() {
  localStorage.removeItem(STORAGE_KEY);
}

// ----------- helpers for managing accounts -----------
function initialsOf(name) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((s) => s[0]?.toUpperCase())
    .join("") || "U";
}

const GRADIENTS = [
  "#6366f1,#22d3ee",
  "#f97316,#ec4899",
  "#22c55e,#0ea5e9",
  "#a855f7,#6366f1",
  "#ef4444,#f59e0b",
  "#06b6d4,#3b82f6",
  "#22c55e,#06b6d4",
];

function pickGradient(seed = 0) {
  return GRADIENTS[seed % GRADIENTS.length];
}

export function listUsersByRole(role) {
  return USERS.filter((u) => u.role === role).map((u) => {
    const { password, ...safe } = u;
    return safe;
  });
}

export function createUser({ name, email, password, role }) {
  if (!name || !email || !password) {
    return { ok: false, error: "Name, email and password are required." };
  }
  if (USERS.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
    return { ok: false, error: "A user with this email already exists." };
  }
  const user = {
    id: `u-${Date.now()}`,
    role,
    name: name.trim(),
    email: email.trim().toLowerCase(),
    password,
    initials: initialsOf(name),
    gradient: pickGradient(USERS.length),
    createdAt: new Date().toISOString().slice(0, 10),
  };
  USERS = [...USERS, user];
  const { password: _pw, ...safe } = user;
  return { ok: true, user: safe };
}

export function deleteUser(id) {
  USERS = USERS.filter((u) => u.id !== id);
  return { ok: true };
}
