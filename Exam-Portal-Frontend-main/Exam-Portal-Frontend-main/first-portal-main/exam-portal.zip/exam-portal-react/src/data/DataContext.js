import React, { createContext, useContext, useEffect, useState } from "react";
import {
  listUsersByRole,
  createUser as createUserApi,
  deleteUser as deleteUserApi,
} from "./auth";

/**
 * Single in-memory store for things the user can create at runtime:
 *  - admins (created by super admin)
 *  - students (created by admin/super admin)
 *  - uploaded PDFs (exam papers, study material — uploaded by admin/super admin)
 *
 * Replace each function below with real API calls when backend is ready.
 */

const DataContext = createContext(null);

const STUDENTS_KEY = "examportal_students";
const PDFS_KEY = "examportal_pdfs";

export function DataProvider({ children }) {
  const [admins, setAdmins] = useState(() => listUsersByRole("admin"));
  const [students, setStudents] = useState(() => {
    try {
      const fromStorage = JSON.parse(localStorage.getItem(STUDENTS_KEY) || "[]");
      // also include any students created via auth (role:student)
      const fromAuth = listUsersByRole("student").map((s) => ({
        id: s.id,
        name: s.name,
        email: s.email,
        roll: "—",
        branch: "—",
        initials: s.initials,
        gradient: s.gradient,
        createdAt: s.createdAt,
        taken: 0,
        avg: "—",
      }));
      // merge unique by email
      const seen = new Set();
      return [...fromAuth, ...fromStorage].filter((s) => {
        if (seen.has(s.email)) return false;
        seen.add(s.email);
        return true;
      });
    } catch {
      return [];
    }
  });
  const [pdfs, setPdfs] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(PDFS_KEY) || "[]");
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(STUDENTS_KEY, JSON.stringify(students));
  }, [students]);
  useEffect(() => {
    // strip the heavy dataUrl from storage to avoid quota issues; keep meta only
    const lite = pdfs.map(({ dataUrl, ...rest }) => rest);
    try {
      localStorage.setItem(PDFS_KEY, JSON.stringify(lite));
    } catch {
      /* ignore quota */
    }
  }, [pdfs]);

  // -------- Admins --------
  const addAdmin = ({ name, email, password }) => {
    const res = createUserApi({ name, email, password, role: "admin" });
    if (res.ok) setAdmins(listUsersByRole("admin"));
    return res;
  };
  const removeAdmin = (id) => {
    deleteUserApi(id);
    setAdmins(listUsersByRole("admin"));
  };

  // -------- Students --------
  const addStudent = ({ name, email, roll, branch, password }) => {
    if (!name || !email || !roll) {
      return { ok: false, error: "Name, email and roll number are required." };
    }
    if (students.some((s) => s.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, error: "A student with this email already exists." };
    }
    // also create a login record so the student can sign in
    if (password) {
      createUserApi({ name, email, password, role: "student" });
    }
    const initials =
      name.split(" ").filter(Boolean).slice(0, 2).map((s) => s[0]?.toUpperCase()).join("") || "S";
    const grad = ["#22c55e,#06b6d4", "#06b6d4,#3b82f6", "#a855f7,#6366f1", "#f97316,#ec4899"][
      students.length % 4
    ];
    const newStudent = {
      id: `s-${Date.now()}`,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      roll: roll.trim(),
      branch: (branch || "—").trim(),
      initials,
      gradient: grad,
      createdAt: new Date().toISOString().slice(0, 10),
      taken: 0,
      avg: "—",
    };
    setStudents((s) => [newStudent, ...s]);
    return { ok: true, student: newStudent };
  };

  const removeStudent = (id) => {
    setStudents((s) => s.filter((x) => x.id !== id));
  };

  // -------- PDFs --------
  const addPdf = ({ title, file, category, dataUrl, uploadedBy }) => {
    const pdf = {
      id: `pdf-${Date.now()}`,
      title: title || file?.name || "Untitled.pdf",
      filename: file?.name || "document.pdf",
      sizeKB: file ? Math.round(file.size / 1024) : 0,
      category: category || "Exam Paper",
      uploadedBy: uploadedBy || "—",
      uploadedAt: new Date().toLocaleString(),
      dataUrl: dataUrl || null,
    };
    setPdfs((p) => [pdf, ...p]);
    return { ok: true, pdf };
  };
  const removePdf = (id) => setPdfs((p) => p.filter((x) => x.id !== id));

  return (
    <DataContext.Provider
      value={{
        admins,
        addAdmin,
        removeAdmin,
        students,
        addStudent,
        removeStudent,
        pdfs,
        addPdf,
        removePdf,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export const useData = () => useContext(DataContext);
