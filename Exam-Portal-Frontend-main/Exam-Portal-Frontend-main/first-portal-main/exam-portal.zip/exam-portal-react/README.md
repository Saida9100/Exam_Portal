# ExamPortal — React UI Template (Role-based)

A professional, modular UI template for the
[Exam_Portal](https://github.com/mahidar22/Exam_Portal) project, rebuilt in
**React 18 + React Router 6** with **role-based authentication** and working
features for managing admins, students and PDF documents.

---

## 🔑 Demo login credentials

Shown on the login page — click any "Use" button to auto-fill.

| Role | Email | Password |
|------|-------|----------|
| 🔴 **Super Admin** | `superadmin@examportal.com` | `Super@123` |
| 🟣 **Admin**       | `admin@examportal.com`      | `Admin@123` |
| 🟢 **Student**     | `student@examportal.com`    | `Student@123` |

---

## ✨ Features added in this version

### 🔴 Super Admin can:
- **Create / delete Admin accounts** (`/app/admins`) — full CRUD with email + password
- **Upload PDFs** (exam papers, study material, etc.) → `/app/documents`
- Add students, manage exams, view proctoring, configure settings — everything

### 🟣 Admin can:
- **Add Students** (`/app/students`) — modal form with name, email, roll, branch, password
  - Creates a real login record so the student can sign in
- **Upload PDFs** (`/app/documents`) — drag & drop or click-to-choose, max 10 MB
  - Categorize as Exam Paper, Question Bank, Study Material, Answer Key
  - View / download / delete from the library

### 🟢 Student can:
- See dashboard, available exams, take exams, view their results

---

## 🛡️ Role-based access (auto-enforced)

| Route               | Super Admin | Admin | Student |
|---------------------|:-----------:|:-----:|:-------:|
| Dashboard           | ✅ | ✅ | ✅ |
| Exams (list)        | ✅ | ✅ | ✅ |
| Live Exam           | ✅ | ✅ | ✅ |
| Results             | ✅ | ✅ | ✅ |
| Create Exam         | ✅ | ✅ | ❌ |
| Proctoring          | ✅ | ✅ | ❌ |
| Students (manage)   | ✅ | ✅ | ❌ |
| **PDF Library**     | ✅ | ✅ | ❌ |
| **Admin Accounts**  | ✅ | ❌ | ❌ |
| Settings            | ✅ | ❌ | ❌ |

Sidebar items hide automatically based on role.

---

## 🚀 Run commands

```bash
cd exam-portal-react
npm install          # first time only
npm start            # http://localhost:3000
npm run build        # production build → /build
```

**Requires:** Node.js ≥ 16 (recommend 18 or 20).

---

## 🧱 Project structure

```
src/
├── index.js                       # entry — wraps App with Auth + Data providers
├── App.js                         # routes + per-route role guards
├── styles/global.css              # design system
├── data/
│   ├── auth.js                    # demo users + create/delete user helpers
│   ├── DataContext.js             # in-memory store: admins, students, PDFs
│   └── mock.js                    # empty arrays — wire to API
├── auth/
│   ├── AuthContext.js             # useAuth(), login(), logout()
│   └── RequireAuth.js             # route guard w/ role filter
└── components/
    ├── AppLayout.js               # Sidebar + Topbar + <Outlet/>
    ├── Sidebar.js                 # role-aware nav (auto-hides items)
    ├── Topbar.js                  # search + role badge + avatar
    ├── ui/                        # Icon, Badge, Card, Avatar, StatCard,
    │                              # EmptyState, Modal (reusable atoms)
    └── pages/
        ├── LoginPage.js
        ├── Dashboard.js
        ├── Exams.js
        ├── CreateExam.js
        ├── ExamTaking.js
        ├── Proctoring.js
        ├── Results.js
        ├── Students.js            # 👈 with "+ Add Student" modal
        ├── Admins.js              # 👈 NEW — Super Admin creates admins
        ├── Documents.js           # 👈 NEW — PDF upload & library
        └── Settings.js
```

---

## 🧠 How the new features work

### 1️⃣ Create Admin Account (Super Admin only)
- Go to **Sidebar → Manage → Admin Accounts**
- Click **+ Create Admin Account**
- Fill name / email / password (min 6 chars) → click "Create admin"
- The new admin appears in the table and can immediately log in with those credentials.
- Implemented in `src/components/pages/Admins.js` → `useData().addAdmin(...)`

### 2️⃣ Add Student (Admin + Super Admin)
- Go to **Sidebar → Manage → Students**
- Click **+ Add Student**
- Fill name / roll / email / branch / temporary password
- The student is added to the list **and** gets a login account so they can sign in.
- Implemented in `src/components/pages/Students.js` → `useData().addStudent(...)`

### 3️⃣ Upload PDF (Admin + Super Admin)
- Go to **Sidebar → Manage → PDF Library**
- Drag & drop a PDF into the dropzone, or click to choose
- Set the title & category (Exam Paper / Question Bank / Study Material / Answer Key / Other)
- Click **⬆️ Upload PDF**
- The PDF appears in the library with **View / Download / Delete** actions.
- File is read with `FileReader.readAsDataURL` and stored in memory — works offline,
  no backend required. Metadata persists across page reloads via `localStorage`.
- Implemented in `src/components/pages/Documents.js` → `useData().addPdf(...)`

---

## 🧩 Plug in your real backend

All mutating actions live in `src/data/DataContext.js`. Replace each function
(`addAdmin`, `addStudent`, `addPdf`) with `fetch`/`axios` calls to your API
and the UI will work exactly the same.

For PDF uploads use `FormData`:

```js
const formData = new FormData();
formData.append("title", title);
formData.append("category", category);
formData.append("file", file);
await fetch("/api/pdfs", { method: "POST", body: formData });
```

---

## 🛠 Improvements over the original repo

- Clean **React Router 6** w/ role guards
- Reusable atomic components incl. **`<Modal/>`** & **`<EmptyState/>`**
- Centralized **CSS design system** (easy to retheme / dark mode)
- Real **drag-and-drop PDF uploader** with size + type validation
- **Two new admin features** (create admins, add students) wired end-to-end
- Empty-state UX everywhere — no fake demo rows
